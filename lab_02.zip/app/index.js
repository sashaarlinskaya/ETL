require('dotenv').config();
const express = require('express');
const fs = require('fs');
const csv = require('csv-parser');
const { generateAndSaveCSV } = require('./generate');

const app = express();
const PORT = process.env.PORT || 3000;
const CSV_PATH = process.env.CSV_PATH || './data/inventory.csv';
const ITEMS_COUNT = parseInt(process.env.ITEMS_COUNT || '50', 10);

let inventoryCache = [];

async function loadCSV(filePath) {
  return new Promise((resolve, reject) => {
    const rows = [];
    fs.createReadStream(filePath)
      .pipe(csv({ separator: ';' }))
      .on('data', (row) => {
        rows.push({
          sku: row['SKU'],
          name: row['Наименование'],
          category: row['Категория'],
          unit: row['Единица'],
          stock_qty: parseFloat(row['Остаток']),
          sales_speed: parseFloat(row['Скорость_продаж_день']),
          expiry_days: parseInt(row['Срок_годности_дней'], 10),
          days_until_stockout: parseFloat(row['Дней_до_обнуления']),
          supplier: row['Поставщик'],
        });
      })
      .on('end', () => resolve(rows))
      .on('error', reject);
  });
}

async function init() {
  const csvExists = fs.existsSync(CSV_PATH);

  if (!csvExists) {
    console.log('CSV не найден, генерируем данные...');
    inventoryCache = await generateAndSaveCSV(CSV_PATH, ITEMS_COUNT);
  } else {
    console.log('CSV найден, загружаем данные...');
    inventoryCache = await loadCSV(CSV_PATH);
    console.log(`Загружено записей: ${inventoryCache.length}`);
  }
}

app.get('/inventory', (req, res) => {
  res.json({
    total: inventoryCache.length,
    items: inventoryCache,
  });
});

app.get('/filter', (req, res) => {
  const min = parseFloat(req.query.min);
  const metric = req.query.metric || 'stock_qty';

  const allowedMetrics = ['stock_qty', 'sales_speed', 'expiry_days', 'days_until_stockout'];

  if (isNaN(min)) {
    return res.status(400).json({
      error: 'Параметр min обязателен и должен быть числом',
      example: '/filter?min=100',
    });
  }

  if (!allowedMetrics.includes(metric)) {
    return res.status(400).json({
      error: `Недопустимая метрика. Доступные: ${allowedMetrics.join(', ')}`,
    });
  }

  const filtered = inventoryCache.filter((item) => item[metric] > min);

  res.json({
    metric,
    min,
    total: filtered.length,
    items: filtered,
  });
});

app.get('/stats', (req, res) => {
  if (inventoryCache.length === 0) {
    return res.json({ message: 'Данных нет' });
  }

  const totalStock = inventoryCache.reduce((s, i) => s + i.stock_qty, 0);
  const avgSalesSpeed = inventoryCache.reduce((s, i) => s + i.sales_speed, 0) / inventoryCache.length;
  const avgExpiry = inventoryCache.reduce((s, i) => s + i.expiry_days, 0) / inventoryCache.length;
  const criticalItems = inventoryCache.filter((i) => i.days_until_stockout < 7).length;

  const byCategory = inventoryCache.reduce((acc, item) => {
    acc[item.category] = (acc[item.category] || 0) + 1;
    return acc;
  }, {});

  const bySupplier = inventoryCache.reduce((acc, item) => {
    acc[item.supplier] = (acc[item.supplier] || 0) + 1;
    return acc;
  }, {});

  res.json({
    total_items: inventoryCache.length,
    total_stock_units: totalStock,
    avg_sales_speed_per_day: parseFloat(avgSalesSpeed.toFixed(2)),
    avg_expiry_days: parseFloat(avgExpiry.toFixed(1)),
    critical_stockout_items: criticalItems,
    by_category: byCategory,
    by_supplier: bySupplier,
  });
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok', items_loaded: inventoryCache.length });
});

init()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Сервер запущен на порту ${PORT}`);
      console.log(`GET /inventory          — все товары`);
      console.log(`GET /filter?min=X       — фильтр по остатку > X`);
      console.log(`GET /filter?min=X&metric=sales_speed — фильтр по любой метрике`);
      console.log(`GET /stats              — агрегированная статистика`);
      console.log(`GET /health             — healthcheck`);
    });
  })
  .catch((err) => {
    console.error('Ошибка инициализации:', err);
    process.exit(1);
  });
