const fs = require('fs');
const path = require('path');
const { createObjectCsvWriter } = require('csv-writer');

const SUPPLIERS = [
  'ООО Ромашка', 'ИП Иванов', 'ЗАО МегаПоставка', 'ООО ТоргСнаб',
  'ПАО Логистика', 'ООО АгроПром', 'ИП Петров', 'ООО СнабЦентр',
  'ЗАО ТехноСнаб', 'ООО РусИмпорт'
];

const PRODUCTS = [
  { name: 'Молоко 3.2%', category: 'Молочные продукты', unit: 'л' },
  { name: 'Хлеб белый', category: 'Хлебобулочные изделия', unit: 'шт' },
  { name: 'Сахар-песок', category: 'Бакалея', unit: 'кг' },
  { name: 'Гречка ядрица', category: 'Крупы', unit: 'кг' },
  { name: 'Масло сливочное 82%', category: 'Молочные продукты', unit: 'кг' },
  { name: 'Яйцо куриное С1', category: 'Яйца', unit: 'дес' },
  { name: 'Мука пшеничная в/с', category: 'Бакалея', unit: 'кг' },
  { name: 'Подсолнечное масло', category: 'Масла', unit: 'л' },
  { name: 'Макароны спагетти', category: 'Макаронные изделия', unit: 'кг' },
  { name: 'Рис длиннозёрный', category: 'Крупы', unit: 'кг' },
  { name: 'Соль поваренная', category: 'Бакалея', unit: 'кг' },
  { name: 'Чай чёрный байховый', category: 'Напитки', unit: 'упак' },
  { name: 'Кофе растворимый', category: 'Напитки', unit: 'упак' },
  { name: 'Сметана 20%', category: 'Молочные продукты', unit: 'кг' },
  { name: 'Творог 9%', category: 'Молочные продукты', unit: 'кг' },
  { name: 'Колбаса докторская', category: 'Колбасные изделия', unit: 'кг' },
  { name: 'Сосиски молочные', category: 'Колбасные изделия', unit: 'кг' },
  { name: 'Курица бройлер', category: 'Мясо птицы', unit: 'кг' },
  { name: 'Фарш говяжий', category: 'Мясо', unit: 'кг' },
  { name: 'Минтай б/г', category: 'Рыба', unit: 'кг' },
  { name: 'Огурцы свежие', category: 'Овощи', unit: 'кг' },
  { name: 'Томаты свежие', category: 'Овощи', unit: 'кг' },
  { name: 'Капуста белокочанная', category: 'Овощи', unit: 'кг' },
  { name: 'Картофель', category: 'Овощи', unit: 'кг' },
  { name: 'Морковь', category: 'Овощи', unit: 'кг' },
  { name: 'Лук репчатый', category: 'Овощи', unit: 'кг' },
  { name: 'Бананы', category: 'Фрукты', unit: 'кг' },
  { name: 'Яблоки Голден', category: 'Фрукты', unit: 'кг' },
  { name: 'Апельсины', category: 'Фрукты', unit: 'кг' },
  { name: 'Йогурт питьевой', category: 'Молочные продукты', unit: 'шт' },
];

function rand(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randFloat(min, max, decimals = 1) {
  return parseFloat((Math.random() * (max - min) + min).toFixed(decimals));
}

function randomChoice(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function generateSKU(index) {
  return `SKU-${String(index + 1).padStart(5, '0')}`;
}

function generateExpiryDays(category) {
  const expiryMap = {
    'Молочные продукты': () => rand(3, 30),
    'Хлебобулочные изделия': () => rand(1, 7),
    'Колбасные изделия': () => rand(7, 45),
    'Мясо птицы': () => rand(3, 10),
    'Мясо': () => rand(3, 14),
    'Рыба': () => rand(5, 20),
    'Овощи': () => rand(5, 30),
    'Фрукты': () => rand(7, 21),
    'Крупы': () => rand(180, 730),
    'Бакалея': () => rand(180, 1095),
    'Макаронные изделия': () => rand(365, 730),
    'Масла': () => rand(180, 730),
    'Напитки': () => rand(180, 1095),
    'Яйца': () => rand(14, 25),
  };
  return (expiryMap[category] || (() => rand(30, 365)))();
}

function generateInventory(count) {
  const usedProducts = [];
  const items = [];

  for (let i = 0; i < count; i++) {
    const product = randomChoice(PRODUCTS);
    const stockQty = rand(10, 2000);
    const salesSpeed = randFloat(1, 80);
    const expiryDays = generateExpiryDays(product.category);
    const daysUntilStockout = parseFloat((stockQty / salesSpeed).toFixed(1));

    items.push({
      sku: generateSKU(i),
      name: product.name,
      category: product.category,
      unit: product.unit,
      stock_qty: stockQty,
      sales_speed: salesSpeed,
      expiry_days: expiryDays,
      days_until_stockout: daysUntilStockout,
      supplier: randomChoice(SUPPLIERS),
    });
  }

  return items;
}

async function generateAndSaveCSV(csvPath, count) {
  const dir = path.dirname(csvPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  const items = generateInventory(count);

  const csvWriter = createObjectCsvWriter({
    path: csvPath,
    header: [
      { id: 'sku', title: 'SKU' },
      { id: 'name', title: 'Наименование' },
      { id: 'category', title: 'Категория' },
      { id: 'unit', title: 'Единица' },
      { id: 'stock_qty', title: 'Остаток' },
      { id: 'sales_speed', title: 'Скорость_продаж_день' },
      { id: 'expiry_days', title: 'Срок_годности_дней' },
      { id: 'days_until_stockout', title: 'Дней_до_обнуления' },
      { id: 'supplier', title: 'Поставщик' },
    ],
    fieldDelimiter: ';',
    encoding: 'utf8',
  });

  await csvWriter.writeRecords(items);
  console.log(`CSV сгенерирован: ${csvPath} (${items.length} записей)`);
  return items;
}

module.exports = { generateAndSaveCSV };
