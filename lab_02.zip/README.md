# Inventory API

Node.js / Express API для управления складскими остатками (РФ рынок).

## Структура проекта

```
inventory-api/
├── app/
│   ├── index.js          # Express-сервер, эндпоинты
│   ├── generate.js       # Генератор CSV данных
│   └── package.json
├── data/                 # Папка для CSV (монтируется как volume)
├── .env                  # Переменные окружения
├── .dockerignore
├── Dockerfile
└── docker-compose.yml
```

## Запуск

```bash
# 1. Клонируй / скопируй проект
cd inventory-api

# 2. Запусти
docker compose up --build

# Остановка
docker compose down
```

При первом запуске автоматически генерируется `data/inventory.csv` с 50 позициями.  
При повторном запуске CSV уже существует — данные берутся из него.

Чтобы **пересоздать** CSV — удали файл и перезапусти:
```bash
rm data/inventory.csv && docker compose restart
```

## Переменные окружения (`.env`)

| Переменная    | По умолчанию             | Описание                  |
|---------------|--------------------------|---------------------------|
| `PORT`        | `3000`                   | Порт сервера              |
| `CSV_PATH`    | `/app/data/inventory.csv`| Путь к CSV внутри контейнера |
| `ITEMS_COUNT` | `50`                     | Кол-во генерируемых позиций |

## API Эндпоинты

### `GET /inventory`
Возвращает все товары.

```json
{
  "total": 50,
  "items": [...]
}
```

---

### `GET /filter?min=X[&metric=FIELD]`
Возвращает записи, где значение метрики `> X`.

**Параметры:**
| Параметр | Обязательный | Описание |
|----------|-------------|----------|
| `min`    | ✅           | Пороговое значение (число) |
| `metric` | ❌           | Поле для фильтрации (по умолчанию `stock_qty`) |

**Доступные метрики:**
- `stock_qty` — остаток на складе (ед.)
- `sales_speed` — скорость продаж (ед/день)
- `expiry_days` — срок годности (дней)
- `days_until_stockout` — дней до обнуления запаса

**Примеры:**
```bash
# Товары с остатком > 500 единиц
curl "http://localhost:3000/filter?min=500"

# Товары с продажами > 20 ед/день
curl "http://localhost:3000/filter?min=20&metric=sales_speed"

# Товары со сроком годности > 90 дней
curl "http://localhost:3000/filter?min=90&metric=expiry_days"

# Товары, которых хватит на > 30 дней
curl "http://localhost:3000/filter?min=30&metric=days_until_stockout"
```

---

### `GET /stats`
Агрегированная статистика по складу.

```json
{
  "total_items": 50,
  "total_stock_units": 48320,
  "avg_sales_speed_per_day": 34.7,
  "avg_expiry_days": 185.2,
  "critical_stockout_items": 3,
  "by_category": { "Молочные продукты": 8, ... },
  "by_supplier": { "ООО Ромашка": 6, ... }
}
```

---

### `GET /health`
Healthcheck для Docker.

```json
{ "status": "ok", "items_loaded": 50 }
```

## Структура данных (CSV / JSON)

| Поле                 | Тип    | Описание                          |
|----------------------|--------|-----------------------------------|
| `sku`                | string | Артикул товара (SKU-00001)         |
| `name`               | string | Наименование                      |
| `category`           | string | Категория                         |
| `unit`               | string | Единица измерения                 |
| `stock_qty`          | number | Остаток на складе                 |
| `sales_speed`        | number | Скорость продаж, ед/день          |
| `expiry_days`        | number | Срок годности, дней               |
| `days_until_stockout`| number | Дней до обнуления (stock/speed)   |
| `supplier`           | string | Поставщик                         |
